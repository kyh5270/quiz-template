import { runInAction } from 'mobx';
import {
  makeExtendedObservable,
  mobxService,
  Offset,
  OffsetElementList,
  Operator,
  QueryParam,
} from '@nara.drama/prologue';
import { Comment, CommentApiStub, CommentQueryApiStub, CommentsDynamicQuery } from '../../../api';


@mobxService
class CommentsStateKeeper {
  //
  static readonly instanceName = 'commentsStateKeeper';
  static readonly serviceName = 'feedback.comment.commentsStateKeeper';
  static instance: CommentsStateKeeper;

  private readonly commentApi: CommentApiStub;
  private readonly commentQueryApi: CommentQueryApiStub;

  comments: Comment[] = [];

  offset: Offset = {} as Offset;


  constructor(
    commentApi: CommentApiStub = CommentApiStub.instance,
    commentQueryApi: CommentQueryApiStub = CommentQueryApiStub.instance
  ) {
    this.commentApi = commentApi;
    this.commentQueryApi = commentQueryApi;

    makeExtendedObservable(this);
  }

  async findCommentsByFeedbackId(feedbackId: string, offset: Offset): Promise<OffsetElementList<Comment>> {
    //
    const query = CommentsDynamicQuery.oneParam<Comment>(
      QueryParam.endParam('feedbackId', Operator.Equal, feedbackId)
    );

    query.offset = offset;

    return this.findComments(query);
  }

  async findNotDeletedCommentsByFeedbackId(feedbackId: string, offset: Offset): Promise<OffsetElementList<Comment>> {
    //
    const query = CommentsDynamicQuery.multiParams<Comment>(
      QueryParam.andParam('feedbackId', Operator.Equal, feedbackId),
      QueryParam.endParam('deleted', Operator.Equal, 'false')
    );

    query.offset = offset;

    return this.findComments(query);
  }

  private async findComments(query: CommentsDynamicQuery): Promise<OffsetElementList<Comment>> {
    //
    const commentsOffsetElementList = await this.commentQueryApi.executeCommentsDynamicPagingQuery(query);

    query.offset.totalCount = commentsOffsetElementList.totalCount;

    runInAction(() => {
      this.comments = commentsOffsetElementList.results;
      this.offset = query.offset;
    });

    return commentsOffsetElementList;
  }

  setCommentsProp(commentId: string, name: keyof Comment, value: any) {
    //
    this.comments = this.comments.map(comment => (
      comment.id === commentId ?
        { ...comment, [name]: value } as Comment
        : comment)
    );
  }

  clear() {
    //
    this.comments = [];
  }
}


CommentsStateKeeper.instance = new CommentsStateKeeper();

export default CommentsStateKeeper;
