
export { default } from './HeaderView';
