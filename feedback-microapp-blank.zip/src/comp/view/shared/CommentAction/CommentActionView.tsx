
import React from 'react';
import { autobind, ReactComponent } from '@nara.drama/prologue';
import { Button, List, Menu, MenuTypes, Typography } from '@nara.platform/react-ui';
import { Delete, Edit, MoreVert } from '@material-ui/icons';


interface Props {
  //
  commentId: string;
  onClickEdit: (id: string) => void;
  onClickRemove: (id: string) => void;
}

@autobind
class CommentActionView extends ReactComponent<Props> {
  //
  render() {
    //
    const { commentId, onClickEdit, onClickRemove } = this.props;

    return (
      <Menu
        trigger={
          <Button.Icon size="small">
            <MoreVert />
          </Button.Icon>
        }
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Menu.Item
          onClick={(event: React.MouseEvent, params: MenuTypes.ClickItemParams) => {
            params.close();
            onClickEdit(commentId);
          }}
        >
          <List.ItemIcon><Edit /></List.ItemIcon>
          <Typography>Edit</Typography>
        </Menu.Item>
        <Menu.Item
          onClick={(event: React.MouseEvent, params: MenuTypes.ClickItemParams) => {
            params.close();
            onClickRemove(commentId);
          }}
        >
          <List.ItemIcon><Delete /></List.ItemIcon>
          <Typography>Remove</Typography>
        </Menu.Item>
      </Menu>
    );
  }
}

export default CommentActionView;
