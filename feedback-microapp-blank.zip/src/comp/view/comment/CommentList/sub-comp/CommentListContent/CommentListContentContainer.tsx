import React, { ContextType } from 'react';
import { autobind, ReactComponent, ServiceInjector } from '@nara.drama/prologue';
import { observer } from 'mobx-react';

import { Comment } from '~/comp/api';
import { CommentsStateKeeper, CommentStateKeeper } from '~/comp/state';
import CommentListContext from '../../context/CommentListContext';
import CommentDetailView from './view/CommentDetailView';


interface Props {
  //
  onClickEdit?: (comment: Comment) => void;
  onSuccess?: () => void;
  onFail?: () => void;
}

interface InjectedProps {
  //
  commentsStateKeeper: CommentsStateKeeper;
  commentStateKeeper: CommentStateKeeper;
}

@autobind
@observer
class CommentListContentContainer extends ReactComponent<Props, {}, InjectedProps> {
  //
  static defaultProps = {
    onClickEdit: () => {},
    renderSub: undefined,
    onSuccess: () => {},
    onFail: () => {},
  };

  static contextType = CommentListContext;

  context!: ContextType<typeof CommentListContext>;


  onToggle(comment: Comment) {
    //
    const { commentsStateKeeper } = this.injected;

    commentsStateKeeper.setCommentsProp(comment.id, 'expanded', !comment.expanded);
  }

  onClickEdit(commentId: string) {
    //
    const { commentsStateKeeper } = this.injected;

    commentsStateKeeper.setCommentsProp(commentId, 'editing', true);
  }

  async onRemove(commentId: string) {
    //
    const { commentStateKeeper } = this.injected;

    const response = await commentStateKeeper.remove(commentId);
    const success = !!response.entityIds.length;

    this.onComplete(success);
  }

  onModify(success: boolean) {
    //
    const { commentList } = this.context;

    commentList.init();
    this.onComplete(success);
  }

  onComplete(success: boolean) {
    //
    const { commentList } = this.context;
    const { onSuccess, onFail } = this.propsWithDefault;

    if (success) {
      onSuccess();
    }
    else {
      onFail();
    }

    commentList.init();
  }

  render() {
    //
    const { commentList } = this.context;
    const { writerName } = commentList;

    const { commentsStateKeeper } = this.injected;
    const { comments } = commentsStateKeeper;

    return comments.map((comment, index) => (
      <CommentDetailView
        key={index}
        comment={comment}
        userId={commentList.userId}
        sourceEntityId={commentList.sourceEntityId}
        sourceEntityName={commentList.sourceEntityName}
        anonymous={false}
        onClickEdit={this.onClickEdit}
        onClickRemove={this.onRemove}
        onClickReplies={this.onToggle}
        onModify={this.onModify}
        writerName={writerName}
      />
    ));
  }
}

export default ServiceInjector.useContext(
  CommentsStateKeeper,
  CommentStateKeeper
)(CommentListContentContainer);
