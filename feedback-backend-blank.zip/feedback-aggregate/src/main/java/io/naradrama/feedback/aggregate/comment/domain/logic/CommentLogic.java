/*
 COPYRIGHT (c) NEXTREE Inc. 2014
 This software is the proprietary of NEXTREE Inc.
 @since 2014. 6. 10.
*/
package io.naradrama.feedback.aggregate.comment.domain.logic;

import io.naradrama.feedback.aggregate.comment.api.command.command.CommentCommand;
import io.naradrama.feedback.aggregate.comment.domain.entity.Comment;
import io.naradrama.feedback.aggregate.comment.domain.entity.sdo.CommentCdo;
import io.naradrama.feedback.aggregate.comment.store.CommentStore;
import io.naradrama.prologue.domain.NameValueList;
import io.naradrama.prologue.domain.Offset;
import io.naradrama.prologue.domain.cqrs.FailureMessage;
import io.naradrama.prologue.domain.cqrs.command.CommandResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import java.lang.String;

@Service
@Transactional
public class CommentLogic {
    // Autogen by nara studio
    private final CommentStore commentStore;

    public CommentLogic(CommentStore commentStore) {
        /* Autogen by nara studio */
        this.commentStore = commentStore;
    }

    public CommentCommand routeCommand(CommentCommand command) {
        switch(/* Autogen by nara studio */
        command.getCqrsBaseCommandType()) {
            case Register:
                if (command.getCommentCdos().size() > 0) {
                    List<String> entityIds = this.registerComments(command.getCommentCdos());
                    command.setCommandResponse(new CommandResponse(entityIds));
                } else {
                    String entityId = this.registerComment(command.getCommentCdo());
                    command.setCommandResponse(new CommandResponse(entityId));
                }
                break;
            case Modify:
                this.modifyComment(command.getCommentId(), command.getNameValues());
                command.setCommandResponse(new CommandResponse(command.getCommentId()));
                break;
            case Remove:
                this.removeComment(command.getCommentId());
                command.setCommandResponse(new CommandResponse(command.getCommentId()));
                break;
            default:
                command.setFailureMessage(new FailureMessage(new Throwable("CommandType must be Register, Modify or Remove")));
        }
        return command;
    }

    public String registerComment(CommentCdo commentCdo) {
        //
        // TODO
        //  1. Save entity from cdo when entity was not exists
        //  2. Return registered entity's id
        System.out.println("registerComment >>>>>>>>>>");

        Comment comment = new Comment(commentCdo);
        if(commentStore.exists(comment.getId())) {
            throw new IllegalArgumentException("comment already exists. " + comment.getId());
        }
        commentStore.create(comment);
        System.out.println("comment " + comment.getId());

        return comment.getId();
    }

    public List<String> registerComments(List<CommentCdo> commentCdos) {
        //
        // TODO
        //  1. Register entities from cdo list
        //  2. Return registered entity's id list
        System.out.println("registerComments >>>>>>>>>>");

        return commentCdos.stream().map(commentCdo -> this.registerComment(commentCdo)).collect(Collectors.toList());
    }

    public Comment findComment(String commentId) {
        //
        // TODO
        //  1. Find entity by optimal query condition
        //  2. If result was empty, throw exception
        System.out.println("findComment >>>>>>>>>>");

        Comment comment = commentStore.retrieve(commentId);
        if(comment == null) {
            throw new NoSuchElementException("Comment id : " + commentId);
        }
        return comment;
    }

    public List<Comment> findAllComment(Offset offset) {
        //
        // TODO
        //  1. Find entities by optimal query conditions
        System.out.println("findAllComment >>>>>>>>>>");

        return commentStore.retrieveAll(offset);
    }

    public void modifyComment(String commentId, NameValueList nameValues) {
        //
        // TODO
        //  1. Modify entity
        System.out.println("modifyComment >>>>>>>>>>");

        Comment comment = findComment(commentId);
        comment.modifyValues(nameValues);
        commentStore.update(comment);

    }

    public void modifyComment(Comment comment) {
        //
        // TODO
        //  1. Modify entity
        System.out.println("modifyComment >>>>>>>>>>");

        Comment foundComment = findComment(comment.getId());
        commentStore.update(comment);
    }

    public void removeComment(String commentId) {
        //
        // TODO
        //  1. Remove entity
        System.out.println("removeComment >>>>>>>>>>");

        Comment comment = findComment(commentId);
        commentStore.delete(comment);
    }

    public boolean exists(String commentId) {
        //
        // TODO
        //  1. Check existence
        System.out.println("exists >>>>>>>>>>");

        return commentStore.exists(commentId);
    }
}
